# -*- coding: utf-8 -*-

#------------------------------------------------------------------
# LEIA E PREENCHA O CABEÇALHO 
#------------------------------------------------------------------

'''

    Nome:
    NUSP:

    Ao preencher esse cabeçalho com o meu nome e o meu número USP,
    declaro que todas as partes originais desse exercício programa
    foram desenvolvidas e implementadas por mim e que, portanto, não 
    constituem desonestidade acadêmica ou plágio.
    
    Entendo que trabalhos sem assinatura devem receber nota zero e, ainda
    assim, poderão ser punidos por desonestidade acadêmica.
    Declaro também que sou responsável por todas as cópias desse
    programa e que não distribui ou facilitei a sua distribuição.
    
    Estou ciente que os casos de plágio e desonestidade acadêmica
    estarão sujeitos às penalidades descritas na página da disciplina
    na seção "Sobre colaboração em MAC0122".

    Reconheço que utilizei as seguintes fontes externas ao conteúdo 
    utilizado e recomendado em MAC0122, ou recebi auxílio das pessoas
    listadas abaixo.

    - LISTA de fontes externas utilizadas (links ou referências como livros)
        - 

    - LISTA das pessoas que me auxiliaram a fazer esse trabalho
        - 
'''

## ==================================================================
def main():
    ''' Unidade de teste da classe MaxHeap '''
    print("Testes do EG24 - ordenação usando max heap")

    x = [21, 12, 43, 61, 41, 71, 91, 31, 81]
    print(f"Entrada:\n{x}")

    print("\n testes do MaxHeap.insira()")
    h = MaxHeap()
    for item in x:
        h.insira(item)
        print(h)
        input("Tecle enter para continuar ...")

    print("\n teste do construa")
    h = MaxHeap()
    h.construa(x)
    print(h)

    #------------------------------------------
    print("\n teste do MaxHeap.remova()")
    print(h)
    while not h.vazio():
        print(f"removi {h.remova()}")
        print(h)
        input("Tecle enter para continuar ...")
    
    #------------------------------------------
    print("\n testes do heapsort")
    x = [21, 12, 43, 61, 41, 71, 91, 31, 81]
    print(f"x  antes: {x}")
    heapsort(x)
    print(f"x depois: {x}")

    y = ['aa', 'c', 'e', 'aa', 'z', 'a-b', 'ef', 'b', 'a', 'cz']
    print(f"y  antes: {y}")
    heapsort(y)
    print(f"y depois: {y}")
    
## ==================================================================
def heapsort(seq):
    '''(list) -> None
    RECEBE uma lista seq.
    REARRANJA os elementos de seq de tal forma que fiquem em ordem
        crescente.
    Usa a classe MaxHeap. Adaptação mutadora de heapsort() em
    https://docs.python.org/3/library/heapq.html

    EXEMPLOS

    In [2]: x = [21, 12, 43, 61, 41, 71, 91, 31, 81]
    In [3]: heapsort(x)
    In [4]: x
    Out[4]: [12, 21, 31, 41, 43, 61, 71, 81, 91]

    In [5]: y = ['aa', 'c', 'e', 'aa', 'z', 'a-b', 'ef', 'b', 'a', 'cz']
    In [6]: heapsort(y)
    In [7]: y
    Out[7]: ['a', 'a-b', 'aa', 'aa', 'b', 'c', 'cz', 'e', 'ef', 'z']
    '''
    n = len(seq)
    # pré-processamento: crie um MaxHeap com elementos de seq 
    h = MaxHeap()
    for item in seq: h.insira(item)
    
    # ordenação por seleção
    for i in range(n-1, -1, -1):
        # maior vai para o final
        seq[i] = h.remova() 

## ==================================================================

class MaxHeap:
    #-----------------------------------------------------
    def __init__(self):
        '''(MaxHeap) -> None
        CONSTRUTOR da classe MaxHeap.
        CRIA uma lista self.data com [None] que representa 
             um MaxHeap vazio.

        Os itens do MaxHeap serão armazenados em
        self.data[1], self.data[2], ... , self.data[n-1]

        PERIGO. o elemento na posição de índice zero não 
            faz parte do MaxHeap. O primeiro elemento 
            está na posição de índice 1.
        '''
        self.data = [None]

    #-----------------------------------------------------        
    def __len__(self):
        ''' (MaxHeap) -> int
        RECEBE um MaxHeap self.
        RETORNA o número de elementos no MaxHeap self.

        EXEMPLOS

        In [12]: h = MaxHeap()
        In [13]: len(h)
        Out[13]: 0

        In [15]: h.insira(7)
        In [16]: h.insira(3)
        In [17]: h.insira(9)
        In [18]: print(h)
        9	
        3	7	
        In [19]: len(h)
        Out[19]: 3
        '''
        return len(self.data) - 1

    #-----------------------------------------------------        
    def vazio(self):
        ''' (MaxHeap) -> bool
        RECEBE um MaxHeap self.
        RETORNA True se o MaxHeap está vazio e False em caso 
            contrário.
        
        EXEMPLOS

        In [12]: h = MaxHeap()
        In [13]: len(h)
        Out[13]: 0
        In [14]: h.vazio()
        Out[14]: True

        In [15]: h.insira(7)
        In [16]: h.insira(3)
        In [17]: h.insira(9)
        In [19]: len(h)
        Out[19]: 3

        In [20]: h.vazio()
        Out[20]: False
        '''
        return len(self) == 0 # equivalente a len(self.data) == 1
  
    #-----------------------------------------------------        
    def maxheap(self):
        ''' (MaxHeap) -> bool
        RECEBE um MaxHeap self.
        RETORNA True se self.data representa um max-heap e False 
            em caso contrário.

        EXEMPLOS                

        In [21]: h  = MaxHeap()
        In [22]: h.maxheap()
        Out[22]: True

        In [23]: h.data = [None, 1, 2, 3]
        In [24]: h.maxheap()
        Out[24]: False

        In [25]: h.data = [3, 1, 2]
        In [26]: h.maxheap()
        Out[26]: False

        In [27]: h.data = [None, 3, 1, 2]
        In [28]: h.maxheap()
        Out[28]: True
        '''
        # apelidos 
        n = len(self.data)
        dt = self.data
        # deve ter pelo menos None
        if n == 0: return False
        # primeira posição deve ser None
        if dt[0] != None: return False
        # verifique se satisfaz a propriedade/invarinte de max-heap
        for filha in range(2, n):
            mae = filha // 2
            # mãe deve ser maior ou igual a filha
            if dt[mae] < dt[filha]: return False
        return True
    
    #-----------------------------------------------------
    def __str__(self):
        ''' (MaxHeap) -> str
        RECEBE um MaxHeap self.
        RETORNA uma string usada para exibir o MaxHeap.
        Método usado pelas funções print() e str().
        '''
        # apelidos 
        n = len(self.data)
        dt = self.data
        # construa a string txt que representa o MaxHeap.
        txt = '\n'
        nivel = 0
        # pecorra o MaxHeap
        i = 1 
        while i < n:
            fim = 2 ** nivel
            nivel += 1
            filho = 0
            while i < n and filho < fim:
                txt += f'{dt[i]}\t'
                i += 1
                filho += 1
            txt += '\n'
        return txt

    #-----------------------------------------------------
    def insira(self, item):                           # EI 
        ''' (MaxHeap, obj) -> None
        RECEBE um MaxHeap self e um objeto item.
        INSERE item no MaxHeap. 
        '''
        # escreva sua solução

    #-----------------------------------------------------
    def construa(self, seq):                          # EI   
        ''' (MaxHeap, list) -> None
        RECEBE um MaxHeap self e um lista seq.
        INSERE cada item de seq no MaxHeap.

        EXEMPLOS

        In [41]: h = MaxHeap()
        In [42]: seq = [1,3,5]
        In [43]: h.construa(seq)
        In [44]: print(h)
        5	
        1	3	
        In [45]: h.data
        Out[45]: [None, 5, 1, 3]
        In [46]: seq
        Out[46]: [1, 3, 5]

        In [47]: seq = [4,2,6]
        In [48]: h.construa(seq)
        In [49]: print(h)
        6	
        4	5	
        1	2	3	
        In [50]: h.data
        Out[50]: [None, 6, 4, 5, 1, 2, 3]
        In [51]: seq
        Out[51]: [4, 2, 6]
        '''
        # escreva sua solução

    #-----------------------------------------------------
    def remova(self):                                 # EG
        '''(MaxHeap) -> obj
        RECEBE um MaxHeap self.
        RETORNA e REMOVE o maior item do MaxHeap. 

        EXEMPLOS

        In [2]: h = MaxHeap()
        In [3]: seq = [1, 4, 5, 3, 6]
        In [4]: h.construa(seq)
        In [5]: seq
        Out[5]: [1, 4, 5, 3, 6]
        In [6]: h.data
        Out[6]: [None, 6, 5, 4, 1, 3]

        In [7]: h.remova()
        Out[7]: 6
        In [8]: h.data
        Out[8]: [None, 5, 3, 4, 1]

        In [9]: h.remova()
        Out[9]: 5
        In [10]: h.data
        Out[10]: [None, 4, 3, 1]

        In [11]: h.remova()
        Out[11]: 4
        In [12]: h.data
        Out[12]: [None, 3, 1]

        In [13]: h.remova()
        Out[13]: 3
        In [14]: h.data
        Out[14]: [None, 1]

        In [15]: h.remova()
        Out[15]: 1
        In [16]: h.data
        Out[16]: [None]

        In [17]: h.remova()
        MaxHeap ERRO: tentativa de remoção em max-heap vazio
        '''
        # crie apelidos
        n = len(self.data) # 1 a mais que o número de itens no MaxHeap
        dt = self.data     # itens: dt[1], dt[2],...,dt[n-1]
        # MaxHeap vazio: erro
        if n == 1:
            print("MaxHeap ERRO: tentativa de remoção em max-heap vazio")
            return None
        # escreva sua solução

        
if __name__ == '__main__':
    main()

#---------------------------------------------------------
#
#  PARA EXPERIMENTOS
#
#---------------------------------------------------------

#---------------------------------------------------------
def quicksortI(v):
    '''(list, int, int) -> None
    RECEBE uma lista v.
    REARRANJA os itens de v para que fiquem em ordem crescente.
    É um implementação do algoritmo quicksort, versão iterativa
    '''
    n = len(v)
    e = 0
    d = n
    pilha = []
    pilha.append([e, d])
    while pilha != []:
        e, d = pilha.pop()
        if e < d-1:
            m = separe(v, e, d)
            # empilhe fatia esquerda
            pilha.append([e, m])
            # empilhe fatia direita
            pilha.append([m+1, d])

#---------------------------------------------------------
def separe(v, e, d):
    '''(list, int, int) -> int
    RECEBE uma lista v e inteiros e e d.
    REARRANJA os itens de `v[e: d]` e RETORNA um 
    índice m tal que v[e:m] <= v[m] < v[m+1:r].
    '''
    x = v[d-1] # pivo
    i = e-1
    for j in range(e, d): 
        if v[j] <= x:
            i += 1
            v[i], v[j] = v[j], v[i]
    return i
